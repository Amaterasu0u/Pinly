const samples = [
  ['Crashing waves', 1.2, 'scenery'],
  ['Sunrise road', 1.4, 'scenery'],
  ['Blue ocean wave', 1.3, 'scenery'],
  ['Vintage cameras', 0.9, 'vintage'],
  ['Hazy hay bales', 0.9, 'scenery'],
  ['Desert dunes', 1.0, 'scenery'],
  ['Blue horizon', 1.1, 'scenery'],
  ['Retro road trip', 1.4, 'vintage'],
  ['Seaside meadow', 1.3, 'scenery'],
  ['Lone tree', 1.5, 'scenery'],
  ['Foggy shoreline', 1.5, 'scenery'],
  ['Bridge in the fog', 1.0, 'city'],
  ['Cozy cafe', 1.0, 'city'],
  ['Train platform', 0.8, 'city'],
  ['Seagulls', 0.8, 'animals'],
  ['Sunset over the sea', 1.2, 'scenery'],
  ['Misty green hills', 1.4, 'scenery'],
  ['Wooden pier', 1.2, 'scenery'],
  ['Beach grass', 1.1, 'scenery'],
  ['Statue of Liberty', 0.9, 'city'],
];

export const seedPins = samples.map(([title, ratio, category], i) => ({
  id: 'seed-' + i,
  title,
  ratio,
  category,
  image: `https://picsum.photos/seed/pinly${i}/400/${Math.round(400 * ratio)}`,
  owner: 'seed',   // 'me' = created by the user
  saved: false,
  createdAt: Date.now() - i * 1000,
}));