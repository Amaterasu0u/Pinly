import React from 'react';
import { Image, ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../context/AuthContext';
import { ME, usePins } from '../context/PinsContext';
import { confirmAction } from '../confirm';
import { COLORS, common } from '../theme';

export default function AdminScreen({ navigation }) {
  const { pins, deletePin, resetAll } = usePins();
  const { user, isAdmin } = useAuth();
  const insets = useSafeAreaInsets();

  if (!isAdmin) return <Text style={common.emptyText}>Admins only.</Text>;

  const stats = [
    { label: 'Total pins', value: pins.length },
    { label: 'User pins', value: pins.filter((p) => p.owner === ME).length },
    { label: 'Sample pins', value: pins.filter((p) => p.owner === 'seed').length },
    { label: 'Saved', value: pins.filter((p) => p.saved).length },
  ];

  const askDelete = (pin) =>
    confirmAction('Delete pin?', `"${pin.title}" will be removed.`, 'Delete', () => deletePin(pin.id));

  const askReset = () =>
    confirmAction('Reset all pins?', 'Removes every user pin and restores the sample pins.', 'Reset', resetAll);

  return (
    <View style={[common.screen, { paddingTop: insets.top + 8 }]}>
      <View style={styles.header}>
        <View>
          <Text style={[common.title, { marginBottom: 0 }]}>Admin panel</Text>
          <Text style={styles.sub}>Signed in as {user?.email}</Text>
        </View>
        <TouchableOpacity testID="admin-reset" onPress={askReset}>
          <Ionicons name="refresh-outline" size={24} color={COLORS.mute} />
        </TouchableOpacity>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 30 }}>
        {/* STATS */}
        <View style={styles.statsRow}>
          {stats.map((s) => (
            <View key={s.label} style={styles.statBox}>
              <Text style={styles.statValue}>{s.value}</Text>
              <Text style={styles.statLabel}>{s.label}</Text>
            </View>
          ))}
        </View>

        {/* ALL PINS */}
        <Text style={styles.section}>All pins</Text>
        {pins.length === 0 && <Text style={common.emptyText}>No pins.</Text>}
        {pins.map((pin) => (
          <View key={pin.id} style={styles.row}>
            <TouchableOpacity
              style={styles.rowMain}
              onPress={() => navigation.navigate('PinDetail', { id: pin.id })}
            >
              <Image source={{ uri: pin.image }} style={styles.thumb} />
              <View style={{ flex: 1 }}>
                <Text numberOfLines={1} style={styles.rowTitle}>{pin.title}</Text>
                <Text style={styles.rowMeta}>
                  {pin.owner === ME ? 'User pin' : 'Sample pin'}
                  {pin.saved ? ' · saved' : ''}
                </Text>
              </View>
            </TouchableOpacity>
            <TouchableOpacity testID={`admin-delete-${pin.id}`} onPress={() => askDelete(pin)} style={styles.trash}>
              <Ionicons name="trash-outline" size={20} color={COLORS.red} />
            </TouchableOpacity>
          </View>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingRight: 16, marginBottom: 12 },
  sub: { color: COLORS.mute, marginLeft: 16, marginTop: 2, fontSize: 13 },
  statsRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, paddingHorizontal: 16, marginBottom: 18 },
  statBox: { width: '47%', backgroundColor: COLORS.soft, borderRadius: 16, padding: 14 },
  statValue: { fontSize: 26, fontWeight: '800', color: COLORS.ink },
  statLabel: { color: COLORS.mute, marginTop: 2 },
  section: { marginHorizontal: 16, marginBottom: 8, fontWeight: '700', fontSize: 16, color: COLORS.ink },
  row: { flexDirection: 'row', alignItems: 'center', marginHorizontal: 16, marginBottom: 10, backgroundColor: COLORS.soft, borderRadius: 16, padding: 8 },
  rowMain: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 12 },
  thumb: { width: 48, height: 48, borderRadius: 12, backgroundColor: COLORS.line },
  rowTitle: { color: COLORS.ink, fontWeight: '600' },
  rowMeta: { color: COLORS.mute, fontSize: 12, marginTop: 2 },
  trash: { padding: 10 },
});