import React, { createContext, useContext, useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { FIREBASE_API_KEY } from '../firebase';

const SESSION_KEY = 'session-firebase-v1';
const BASE = 'https://identitytoolkit.googleapis.com/v1/accounts';

const AuthContext = createContext(null);
export const useAuth = () => useContext(AuthContext);

// one helper for every Firebase Auth REST call
const call = async (action, body) => {
  const res = await fetch(`${BASE}:${action}?key=${FIREBASE_API_KEY}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data?.error?.message || 'UNKNOWN');
  return data;
};

const friendlyError = (e) => {
  const code = String(e.message || '');
  if (code.includes('EMAIL_EXISTS')) return 'That email already has an account.';
  if (code.includes('INVALID_EMAIL')) return 'Enter a valid email.';
  if (code.includes('WEAK_PASSWORD')) return 'Use at least 6 characters.';
  if (code.includes('TOO_MANY_ATTEMPTS')) return 'Too many tries. Wait a bit and retry.';
  if (
    code.includes('INVALID_LOGIN_CREDENTIALS') ||
    code.includes('INVALID_PASSWORD') ||
    code.includes('EMAIL_NOT_FOUND')
  ) return 'Wrong email or password.';
  if (code.includes('OPERATION_NOT_ALLOWED')) return 'Email sign-in is not enabled in Firebase.';
  if (code.includes('API key')) return 'The Firebase API key is not valid.';
  if (code.includes('Network') || code.includes('Failed to fetch')) return 'No connection. Try again.';
    return 'Error: ' + code;
};

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // restore the logged-in user when the app starts
  useEffect(() => {
    (async () => {
      try {
        const saved = await AsyncStorage.getItem(SESSION_KEY);
        if (saved) {
          const { id, name, email } = JSON.parse(saved);
          setUser({ id, name, email });
        }
      } catch (e) {
        // ignore, user just sees the welcome screen
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const startSession = async ({ id, name, email, refreshToken }) => {
    await AsyncStorage.setItem(SESSION_KEY, JSON.stringify({ id, name, email, refreshToken }));
    setUser({ id, name, email });
  };

  const signup = async ({ name, email, password }) => {
    try {
      const data = await call('signUp', { email: email.trim(), password, returnSecureToken: true });
      // save the display name on the Firebase account
      await call('update', { idToken: data.idToken, displayName: name.trim(), returnSecureToken: false });
      await startSession({
        id: data.localId,
        name: name.trim(),
        email: data.email,
        refreshToken: data.refreshToken,
      });
      return { ok: true };
    } catch (e) {
      return { ok: false, error: friendlyError(e) };
    }
  };

  const login = async ({ email, password }) => {
    try {
      const data = await call('signInWithPassword', {
        email: email.trim(),
        password,
        returnSecureToken: true,
      });
      await startSession({
        id: data.localId,
        name: data.displayName || 'Friend',
        email: data.email,
        refreshToken: data.refreshToken,
      });
      return { ok: true };
    } catch (e) {
      return { ok: false, error: friendlyError(e) };
    }
  };

  const logout = async () => {
    await AsyncStorage.removeItem(SESSION_KEY);
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, loading, signup, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}