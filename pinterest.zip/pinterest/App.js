import React from 'react';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { AuthProvider } from './context/AuthContext';
import { PinsProvider } from './context/PinsContext';
import AppNavigator from './MainNavigator';

export default function App() {
  return (
    <SafeAreaProvider>
      <AuthProvider>
        <PinsProvider>
          <AppNavigator />
        </PinsProvider>
      </AuthProvider>
    </SafeAreaProvider>
  );
}