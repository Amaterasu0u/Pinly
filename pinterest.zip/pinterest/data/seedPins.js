const samples = [
  ['Autumn kitchen', 1.3],
  ['Reading nook', 0.8],
  ['Tokyo night', 1.5],
  ['Plant shelf', 1.1],
  ['Ceramic mugs', 0.9],
  ['Mountain cabin', 1.4],
  ['Sketchbook', 1.0],
  ['Minimal desk', 1.2],
];
 
export const seedPins = samples.map(([title, ratio], i) => ({
  id: 'seed-' + i,
  title,
  ratio,
  image: `https://picsum.photos/seed/pin${i}/400/${Math.round(400 * ratio)}`,
  owner: 'seed',   // 'me' = created by the user
  saved: false,
  createdAt: Date.now() - i * 1000,
}));
 