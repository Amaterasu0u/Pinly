import React, { createContext, useContext, useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

const USERS_KEY = 'users-v1';
const SESSION_KEY = 'session-v1';

const AuthContext = createContext(null);
export const useAuth = () => useContext(AuthContext);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // restore the logged-in user when the app starts
  useEffect(() => {
    (async () => {
      try {
        const saved = await AsyncStorage.getItem(SESSION_KEY);
        if (saved) setUser(JSON.parse(saved));
      } catch (e) {
        // ignore, user just sees the welcome screen
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const readUsers = async () => {
    try {
      const raw = await AsyncStorage.getItem(USERS_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch (e) {
      return [];
    }
  };

  const startSession = async (account) => {
    const session = { id: account.id, name: account.name, email: account.email };
    await AsyncStorage.setItem(SESSION_KEY, JSON.stringify(session));
    setUser(session);
  };

  const signup = async ({ name, email, password }) => {
    const users = await readUsers();
    const cleanEmail = email.trim().toLowerCase();
    if (users.some((u) => u.email === cleanEmail)) {
      return { ok: false, error: 'That email already has an account.' };
    }
    const account = { id: 'user-' + Date.now(), name: name.trim(), email: cleanEmail, password };
    await AsyncStorage.setItem(USERS_KEY, JSON.stringify([...users, account]));
    await startSession(account);
    return { ok: true };
  };

  const login = async ({ email, password }) => {
    const users = await readUsers();
    const cleanEmail = email.trim().toLowerCase();
    const account = users.find((u) => u.email === cleanEmail && u.password === password);
    if (!account) return { ok: false, error: 'Wrong email or password.' };
    await startSession(account);
    return { ok: true };
  };

  const logout = async () => {
    await AsyncStorage.removeItem(SESSION_KEY);
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, loading, signup, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}