import React, { createContext, useContext, useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { seedPins } from '../data/seedPins';
 
const STORAGE_KEY = 'pins-v1';
export const ME = 'me'; // the "current user" id
 
const PinsContext = createContext(null);
 
// Use this in any screen to get the data and actions
export const usePins = () => useContext(PinsContext);
 
export function PinsProvider({ children }) {
  const [pins, setPins] = useState([]);
  const [loading, setLoading] = useState(true);
 
  // STEP 1: load saved pins when the app starts
  useEffect(() => {
    (async () => {
      try {
        const saved = await AsyncStorage.getItem(STORAGE_KEY);
        setPins(saved ? JSON.parse(saved) : seedPins);
      } catch (e) {
        setPins(seedPins);
      } finally {
        setLoading(false);
      }
    })();
  }, []);
 
  // STEP 2: save automatically whenever pins change
  useEffect(() => {
    if (loading) return;
    AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(pins)).catch(() => {});
  }, [pins, loading]);
 
  // ---------- ACTIONS ----------
  const addPin = ({ title, image, ratio }) => {
    const newPin = {
      id: 'pin-' + Date.now(),
      title,
      image,
      ratio,
      owner: ME,
      saved: false,
      createdAt: Date.now(),
    };
    setPins((current) => [newPin, ...current]); // newest first
  };
 
  const toggleSave = (id) =>
    setPins((current) => current.map((p) => (p.id === id ? { ...p, saved: !p.saved } : p)));
 
  const deletePin = (id) => setPins((current) => current.filter((p) => p.id !== id));
 
  const resetAll = () => setPins(seedPins);
 
  return (
    <PinsContext.Provider value={{ pins, loading, addPin, toggleSave, deletePin, resetAll }}>
      {children}
    </PinsContext.Provider>
  );
}