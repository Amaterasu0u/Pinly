import React from 'react';
import { ActivityIndicator, View } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';

import HomeScreen from './screens/HomeScreen';
import CreateScreen from './screens/CreateScreen';
import ProfileScreen from './screens/ProfileScreen';
import PinDetailScreen from './screens/PinDetailScreen';
import WelcomeScreen from './screens/WelcomeScreen';
import LoginScreen from './screens/LoginScreen';
import SignupScreen from './screens/SignupScreen';
import { useAuth } from './context/AuthContext';
import { COLORS } from './theme';

const Tab = createBottomTabNavigator();
const Stack = createNativeStackNavigator();

// ---------- the bottom tabs ----------
function Tabs() {
  const icons = { Home: 'home', Create: 'add-circle', Profile: 'person' };

  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarShowLabel: false,
        tabBarActiveTintColor: COLORS.red,
        tabBarInactiveTintColor: COLORS.mute,
        tabBarIcon: ({ color, focused }) => {
          const base = icons[route.name];
          const isCreate = route.name === 'Create';
          return (
            <Ionicons
              name={focused || isCreate ? base : base + '-outline'}
              size={isCreate ? 32 : 24}
              color={color}
            />
          );
        },
      })}
    >
      <Tab.Screen name="Home" component={HomeScreen} />
      <Tab.Screen name="Create" component={CreateScreen} />
      <Tab.Screen name="Profile" component={ProfileScreen} />
    </Tab.Navigator>
  );
}

// ---------- shown when logged IN ----------
function AppStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen name="Tabs" component={Tabs} options={{ headerShown: false }} />
      <Stack.Screen
        name="PinDetail"
        component={PinDetailScreen}
        options={{ title: '', headerTintColor: COLORS.ink, headerStyle: { backgroundColor: COLORS.paper } }}
      />
    </Stack.Navigator>
  );
}

// ---------- shown when logged OUT ----------
function AuthStack() {
  const header = {
    title: '',
    headerShadowVisible: false,
    headerTintColor: COLORS.ink,
    headerStyle: { backgroundColor: COLORS.paper },
  };

  return (
    <Stack.Navigator>
      <Stack.Screen name="Welcome" component={WelcomeScreen} options={{ headerShown: false }} />
      <Stack.Screen name="Login" component={LoginScreen} options={header} />
      <Stack.Screen name="Signup" component={SignupScreen} options={header} />
    </Stack.Navigator>
  );
}

export default function AppNavigator() {
  const { user, loading } = useAuth();

  // wait until we know whether someone is already logged in
  if (loading) {
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: COLORS.paper }}>
        <ActivityIndicator color={COLORS.red} />
      </View>
    );
  }

  return <NavigationContainer>{user ? <AppStack /> : <AuthStack />}</NavigationContainer>;
}