import { Dimensions, StyleSheet } from 'react-native';
 
// ---- COLORS (change these to re-theme the whole app) ----
export const COLORS = {
  ink: '#1d1b19',    // main text / dark buttons
  paper: '#fbfaf7',  // screen background
  red: '#e60023',    // main accent (Pinterest red)
  mute: '#7a7570',   // grey text
  line: '#e6e2da',   // borders / image placeholders
  soft: '#efece5',   // search bar / empty boxes
};
 
// ---- GRID SIZES ----
export const GAP = 10; // space between pins
export const COLUMN_WIDTH = (Dimensions.get('window').width - GAP * 3) / 2;
 
// ---- SHARED STYLES (used by more than one screen) ----
export const common = StyleSheet.create({
  screen: { flex: 1, backgroundColor: COLORS.paper },
  title: { fontSize: 26, fontWeight: '700', color: COLORS.ink, marginHorizontal: 16, marginBottom: 12 },
  emptyText: { textAlign: 'center', color: COLORS.mute, marginTop: 48, paddingHorizontal: 32, fontSize: 15 },
 
  // Red filled button
  button: { backgroundColor: COLORS.red, paddingVertical: 14, borderRadius: 24, alignItems: 'center' },
  buttonText: { color: '#fff', fontWeight: '700', fontSize: 16 },
 
  // White button with a border
  buttonOutline: {
    flex: 1, flexDirection: 'row', gap: 6, justifyContent: 'center', alignItems: 'center',
    paddingVertical: 12, borderRadius: 24, borderWidth: 1, borderColor: COLORS.ink,
  },
  buttonOutlineText: { color: COLORS.ink, fontWeight: '600' },
 
  // Text box
  input: {
    borderWidth: 1, borderColor: COLORS.line, borderRadius: 14, padding: 14,
    fontSize: 16, color: COLORS.ink, marginBottom: 14, backgroundColor: '#fff',
  },
});