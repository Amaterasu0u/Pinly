export const BRAND = {
  name: 'Pinly',
  tagline: 'Collect the little things.',
};