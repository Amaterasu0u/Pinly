import React from 'react';
import { Image, StyleSheet, Text, TouchableOpacity } from 'react-native';
import { COLORS, COLUMN_WIDTH, GAP } from '../theme';
 
export default function PinCard({ pin, onPress }) {
  return (
    <TouchableOpacity
      testID={`pin-${pin.id}`}
      activeOpacity={0.85}
      onPress={onPress}
      style={{ marginBottom: GAP }}
    >
      <Image
        source={{ uri: pin.image }}
        style={[styles.image, { height: COLUMN_WIDTH * pin.ratio }]}
      />
      <Text numberOfLines={1} style={styles.title}>{pin.title}</Text>
    </TouchableOpacity>
  );
}
 
const styles = StyleSheet.create({
  image: { width: COLUMN_WIDTH, borderRadius: 16, backgroundColor: COLORS.line },
  title: { marginTop: 6, marginLeft: 4, color: COLORS.ink, fontSize: 13, width: COLUMN_WIDTH - 8 },
});