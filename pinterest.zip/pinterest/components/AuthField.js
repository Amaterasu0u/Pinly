import React, { useState } from 'react';
import { Platform, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { COLORS } from '../theme';

export default function AuthField({ label, icon, secure, error, ...props }) {
  const [hidden, setHidden] = useState(!!secure);
  const [focused, setFocused] = useState(false);

  return (
    <View style={styles.wrap}>
      <Text style={styles.label}>{label}</Text>
      <View
        style={[
          styles.box,
          focused && { borderColor: COLORS.red, backgroundColor: COLORS.paper },
          !!error && { borderColor: COLORS.red },
        ]}
      >
        <Ionicons name={icon} size={18} color={focused ? COLORS.red : COLORS.mute} />
        <TextInput
          style={[styles.input, Platform.select({ web: { outlineStyle: 'none' } })]}
          placeholderTextColor={COLORS.mute}
          secureTextEntry={hidden}
          autoCapitalize="none"
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          {...props}
        />
        {secure && (
          <TouchableOpacity onPress={() => setHidden((h) => !h)}>
            <Ionicons name={hidden ? 'eye-outline' : 'eye-off-outline'} size={20} color={COLORS.mute} />
          </TouchableOpacity>
        )}
      </View>
      {!!error && <Text style={styles.error}>{error}</Text>}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { marginBottom: 14 },
  label: { color: COLORS.ink, fontWeight: '600', marginBottom: 6, marginLeft: 4 },
  box: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    paddingHorizontal: 16, paddingVertical: 13, borderRadius: 16,
    backgroundColor: COLORS.soft, borderWidth: 1.5, borderColor: 'transparent',
  },
  input: { flex: 1, color: COLORS.ink, fontSize: 16 },
  error: { color: COLORS.red, marginTop: 5, marginLeft: 4, fontSize: 13 },
});