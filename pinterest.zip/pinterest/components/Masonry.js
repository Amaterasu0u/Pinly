import React from 'react';
import { Text, View } from 'react-native';
import PinCard from './PinCard';
import { common, GAP } from '../theme';
 
export default function Masonry({ pins, onOpen, empty }) {
  if (pins.length === 0) return <Text style={common.emptyText}>{empty}</Text>;
 
  const leftColumn = pins.filter((_, i) => i % 2 === 0);
  const rightColumn = pins.filter((_, i) => i % 2 === 1);
 
  return (
    <View style={{ flexDirection: 'row', paddingHorizontal: GAP, gap: GAP }}>
      {[leftColumn, rightColumn].map((column, index) => (
        <View key={index}>
          {column.map((pin) => (
            <PinCard key={pin.id} pin={pin} onPress={() => onOpen(pin)} />
          ))}
        </View>
      ))}
    </View>
  );
}
 