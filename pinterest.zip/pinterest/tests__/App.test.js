import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react-native';
import App from '../App';
 
jest.mock('@react-native-async-storage/async-storage', () =>
  require('@react-native-async-storage/async-storage/jest/async-storage-mock')
);
jest.mock('expo-image-picker', () => ({
  requestCameraPermissionsAsync: jest.fn(async () => ({ granted: true })),
  requestMediaLibraryPermissionsAsync: jest.fn(async () => ({ granted: true })),
  launchCameraAsync: jest.fn(async () => ({ canceled: true })),
  launchImageLibraryAsync: jest.fn(async () => ({ canceled: true })),
}));
 
describe('Pinterest app', () => {
  it('shows sample pins on Home', async () => {
    render(<App />);
    expect(await screen.findByText('Autumn kitchen')).toBeTruthy();
  });
 
  it('filters pins with the search box', async () => {
    render(<App />);
    await screen.findByText('Autumn kitchen');
    fireEvent.changeText(screen.getByTestId('search-input'), 'tokyo');
    expect(screen.queryByText('Autumn kitchen')).toBeNull();
    expect(screen.getByText('Tokyo night')).toBeTruthy();
  });
});
 