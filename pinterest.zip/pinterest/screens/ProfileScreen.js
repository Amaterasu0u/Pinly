import React, { useState } from 'react';
import { Alert, ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import Masonry from '../components/Masonry';
import { useAuth } from '../context/AuthContext';
import { ME, usePins } from '../context/PinsContext';
import { COLORS, common } from '../theme';

export default function ProfileScreen({ navigation }) {
  const { pins, resetAll } = usePins();
  const { user, logout } = useAuth();
  const [tab, setTab] = useState('created'); // 'created' or 'saved'
  const insets = useSafeAreaInsets();

  const created = pins.filter((p) => p.owner === ME);
  const saved = pins.filter((p) => p.saved);
  const list = tab === 'created' ? created : saved;

  const confirmReset = () =>
    Alert.alert('Reset app?', 'This removes your pins and restores the sample pins.', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Reset', style: 'destructive', onPress: resetAll },
    ]);

  const confirmLogout = () =>
    Alert.alert('Log out?', '', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Log out', onPress: logout },
    ]);

  return (
    <View style={[common.screen, { paddingTop: insets.top + 8 }]}>
      {/* HEADER */}
      <View style={styles.header}>
        <Text style={[common.title, { marginBottom: 0 }]}>
          {user ? user.name + "'s pins" : 'Your profile'}
        </Text>
        <View style={{ flexDirection: 'row', gap: 16 }}>
          <TouchableOpacity testID="reset-btn" onPress={confirmReset}>
            <Ionicons name="refresh-outline" size={22} color={COLORS.mute} />
          </TouchableOpacity>
          <TouchableOpacity testID="logout-btn" onPress={confirmLogout}>
            <Ionicons name="log-out-outline" size={22} color={COLORS.mute} />
          </TouchableOpacity>
        </View>
      </View>

      {/* CREATED / SAVED SWITCH */}
      <View style={styles.segment}>
        {['created', 'saved'].map((name) => (
          <TouchableOpacity
            key={name}
            testID={`tab-${name}`}
            onPress={() => setTab(name)}
            style={[styles.segButton, tab === name && styles.segButtonOn]}
          >
            <Text style={[styles.segText, tab === name && { color: '#fff' }]}>
              {name === 'created' ? `Created (${created.length})` : `Saved (${saved.length})`}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* GRID */}
      <ScrollView showsVerticalScrollIndicator={false}>
        <Masonry
          pins={list}
          onOpen={(pin) => navigation.navigate('PinDetail', { id: pin.id })}
          empty={tab === 'created' ? 'You have not created any pins yet. Tap + to add one.' : 'Pins you save will show up here.'}
        />
        <View style={{ height: 24 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingRight: 16, marginBottom: 12 },
  segment: { flexDirection: 'row', gap: 8, marginHorizontal: 16, marginBottom: 14 },
  segButton: { paddingVertical: 8, paddingHorizontal: 16, borderRadius: 20, backgroundColor: COLORS.soft },
  segButtonOn: { backgroundColor: COLORS.ink },
  segText: { color: COLORS.ink, fontWeight: '600' },
});