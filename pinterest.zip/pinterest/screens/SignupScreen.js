import React, { useState } from 'react';
import { KeyboardAvoidingView, Platform, ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import AuthField from '../components/AuthField';
import { useAuth } from '../context/AuthContext';
import { BRAND } from '../brand';
import { COLORS } from '../theme';

export default function SignupScreen({ navigation }) {
  const { signup } = useAuth();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState({});
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    const next = {};
    if (!name.trim()) next.name = 'What should we call you?';
    if (!/^\S+@\S+\.\S+$/.test(email.trim())) next.email = 'Enter a valid email.';
    if (password.length < 6) next.password = 'Use at least 6 characters.';
    setErrors(next);
    if (Object.keys(next).length) return;

    setBusy(true);
    const result = await signup({ name, email, password });
    setBusy(false);
    if (!result.ok) setErrors({ form: result.error });
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1, backgroundColor: COLORS.paper }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
        <Text style={styles.brand}>{BRAND.name}</Text>
        <Text style={styles.title}>Start your first board</Text>
        <Text style={styles.sub}>It takes about 20 seconds.</Text>

        <AuthField
          testID="signup-name" label="Name" icon="happy-outline" placeholder="Your name"
          autoCapitalize="words" value={name} onChangeText={setName} error={errors.name}
        />
        <AuthField
          testID="signup-email" label="Email" icon="mail-outline" placeholder="you@example.com"
          keyboardType="email-address" value={email} onChangeText={setEmail} error={errors.email}
        />
        <AuthField
          testID="signup-password" label="Password" icon="lock-closed-outline" placeholder="At least 6 characters"
          secure value={password} onChangeText={setPassword} error={errors.password}
        />

        {!!errors.form && <Text style={styles.formError}>{errors.form}</Text>}

        <TouchableOpacity testID="signup-submit" style={[styles.button, busy && { opacity: 0.6 }]} onPress={submit} disabled={busy}>
          <Text style={styles.buttonText}>{busy ? 'Creating...' : 'Sign up'}</Text>
        </TouchableOpacity>

        <View style={styles.switchRow}>
          <Text style={{ color: COLORS.mute }}>Already pinning? </Text>
          <TouchableOpacity onPress={() => navigation.replace('Login')}>
            <Text style={styles.link}>Log in</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  content: { padding: 24, paddingTop: 8 },
  brand: { fontSize: 22, fontWeight: '800', color: COLORS.red, marginBottom: 20 },
  title: { fontSize: 30, fontWeight: '800', color: COLORS.ink },
  sub: { color: COLORS.mute, marginTop: 4, marginBottom: 28, fontSize: 15 },
  formError: { color: COLORS.red, marginBottom: 10, textAlign: 'center' },
  button: { backgroundColor: COLORS.red, borderRadius: 28, paddingVertical: 15, alignItems: 'center', marginTop: 6 },
  buttonText: { color: '#fff', fontWeight: '700', fontSize: 16 },
  switchRow: { flexDirection: 'row', justifyContent: 'center', marginTop: 22 },
  link: { color: COLORS.ink, fontWeight: '700' },
});