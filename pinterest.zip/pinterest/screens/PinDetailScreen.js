import React from 'react';
import { Alert, Dimensions, Image, ScrollView, Text, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { ME, usePins } from '../context/PinsContext';
import { COLORS, common } from '../theme';
 
export default function PinDetailScreen({ route, navigation }) {
  const { pins, toggleSave, deletePin } = usePins();
  const pin = pins.find((p) => p.id === route.params.id);
 
  if (!pin) return <Text style={common.emptyText}>This pin no longer exists.</Text>;
 
  const imageWidth = Dimensions.get('window').width - 32;
 
  const confirmDelete = () =>
    Alert.alert('Delete pin?', 'This cannot be undone.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: () => {
          deletePin(pin.id);
          navigation.goBack();
        },
      },
    ]);
 
  return (
    <ScrollView style={common.screen} contentContainerStyle={{ padding: 16 }}>
      <Image
        source={{ uri: pin.image }}
        style={{ width: imageWidth, height: imageWidth * pin.ratio, borderRadius: 20, backgroundColor: COLORS.line }}
      />
 
      <Text style={[common.title, { marginTop: 16, marginHorizontal: 0 }]}>{pin.title}</Text>
      <Text style={{ color: COLORS.mute, marginBottom: 16 }}>
        {pin.owner === ME ? 'Pinned by you' : 'Pinned by the community'}
      </Text>
 
      {/* SAVE BUTTON */}
      <TouchableOpacity
        testID="save-toggle"
        style={[common.button, pin.saved && { backgroundColor: COLORS.ink }]}
        onPress={() => toggleSave(pin.id)}
      >
        <Text style={common.buttonText}>{pin.saved ? 'Saved' : 'Save'}</Text>
      </TouchableOpacity>
 
      {/* DELETE BUTTON (only for your own pins) */}
      {pin.owner === ME && (
        <TouchableOpacity
          testID="delete-pin"
          style={[common.buttonOutline, { marginTop: 10, flex: 0 }]}
          onPress={confirmDelete}
        >
          <Ionicons name="trash-outline" size={18} color={COLORS.ink} />
          <Text style={common.buttonOutlineText}>Delete pin</Text>
        </TouchableOpacity>
      )}
    </ScrollView>
  );
}