import React from 'react';
import { Image, StyleSheet, Text, TouchableOpacity, useWindowDimensions, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { BRAND } from '../brand';
import { COLORS } from '../theme';

// [height ratio] for each photo, three staggered columns
const columns = [
  { offset: 0, ratios: [1.3, 0.9] },
  { offset: 36, ratios: [0.9, 1.3] },
  { offset: 12, ratios: [1.15, 1.0] },
];

export default function WelcomeScreen({ navigation }) {
  const { width } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const tileWidth = (width - 48 - 20) / 3;

  return (
    <View style={[styles.screen, { paddingTop: insets.top + 16, paddingBottom: insets.bottom + 16 }]}>
      {/* PHOTO COLLAGE */}
      <View style={styles.collage}>
        {columns.map((col, c) => (
          <View key={c} style={{ marginTop: col.offset, gap: 10 }}>
            {col.ratios.map((ratio, r) => (
              <Image
                key={r}
                source={{ uri: `https://picsum.photos/seed/welcome${c}${r}/300/${Math.round(300 * ratio)}` }}
                style={{ width: tileWidth, height: tileWidth * ratio, borderRadius: 18, backgroundColor: COLORS.line }}
              />
            ))}
          </View>
        ))}
      </View>

      {/* BRAND + BUTTONS */}
      <View style={styles.bottom}>
        <Text style={styles.brand}>{BRAND.name}</Text>
        <Text style={styles.tagline}>{BRAND.tagline}</Text>

        <TouchableOpacity testID="go-signup" style={styles.primary} onPress={() => navigation.navigate('Signup')}>
          <Text style={styles.primaryText}>Create an account</Text>
        </TouchableOpacity>
        <TouchableOpacity testID="go-login" style={styles.secondary} onPress={() => navigation.navigate('Login')}>
          <Text style={styles.secondaryText}>I already have an account</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: COLORS.paper, paddingHorizontal: 24 },
  collage: { flexDirection: 'row', justifyContent: 'center', gap: 10, flex: 1, overflow: 'hidden' },
  bottom: { alignItems: 'center', paddingTop: 20 },
  brand: { fontSize: 38, fontWeight: '800', color: COLORS.red, letterSpacing: -1 },
  tagline: { fontSize: 16, color: COLORS.mute, marginTop: 4, marginBottom: 24 },
  primary: { backgroundColor: COLORS.red, borderRadius: 28, paddingVertical: 15, width: '100%', alignItems: 'center' },
  primaryText: { color: '#fff', fontWeight: '700', fontSize: 16 },
  secondary: { paddingVertical: 15, width: '100%', alignItems: 'center' },
  secondaryText: { color: COLORS.ink, fontWeight: '600', fontSize: 15 },
});