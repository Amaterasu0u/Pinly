import React, { useState } from 'react';
import { ActivityIndicator, ScrollView, StyleSheet, TextInput, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Masonry from '../components/Masonry';
import { usePins } from '../context/PinsContext';
import { COLORS, common, GAP } from '../theme';
 
export default function HomeScreen({ navigation }) {
  const { pins, loading } = usePins();
  const [query, setQuery] = useState('');
  const insets = useSafeAreaInsets();
 
  const shownPins = pins.filter((p) => p.title.toLowerCase().includes(query.toLowerCase()));
 
  return (
    <View style={[common.screen, { paddingTop: insets.top + 8 }]}>
      {/* SEARCH BAR */}
      <TextInput
        testID="search-input"
        style={styles.search}
        placeholder="Search pins"
        placeholderTextColor={COLORS.mute}
        value={query}
        onChangeText={setQuery}
      />
 
      {/* PIN GRID (or a spinner while loading) */}
      {loading ? (
        <ActivityIndicator color={COLORS.red} style={{ marginTop: 40 }} />
      ) : (
        <ScrollView showsVerticalScrollIndicator={false}>
          <Masonry
            pins={shownPins}
            onOpen={(pin) => navigation.navigate('PinDetail', { id: pin.id })}
            empty="No pins match your search."
          />
          <View style={{ height: 24 }} />
        </ScrollView>
      )}
    </View>
  );
}
 
const styles = StyleSheet.create({
  search: {
    marginHorizontal: GAP, marginBottom: GAP, paddingHorizontal: 16, paddingVertical: 12,
    borderRadius: 24, backgroundColor: COLORS.soft, color: COLORS.ink, fontSize: 16,
  },
});
 