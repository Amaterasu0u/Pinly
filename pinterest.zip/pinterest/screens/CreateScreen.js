import React, { useState } from 'react';
import { Alert, Image, ScrollView, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as ImagePicker from 'expo-image-picker';
import { Ionicons } from '@expo/vector-icons';
import { usePins } from '../context/PinsContext';
import { COLORS, common } from '../theme';
 
export default function CreateScreen({ navigation }) {
  const { addPin } = usePins();
  const [photo, setPhoto] = useState(null);
  const [title, setTitle] = useState('');
  const insets = useSafeAreaInsets();
 
  // Opens the camera (true) or the gallery (false)
  const choosePhoto = async (useCamera) => {
    // 1. permission
    const permission = useCamera
      ? await ImagePicker.requestCameraPermissionsAsync()
      : await ImagePicker.requestMediaLibraryPermissionsAsync();
 
    if (!permission.granted) {
      Alert.alert('Permission needed', 'Please allow access in your phone settings.');
      return;
    }
 
    // 2. open camera / gallery
    const options = { mediaTypes: ['images'], quality: 0.7 };
    const result = useCamera
      ? await ImagePicker.launchCameraAsync(options)
      : await ImagePicker.launchImageLibraryAsync(options);
 
    // 3. keep the chosen photo
    if (!result.canceled) setPhoto(result.assets[0]);
  };
 
  const publish = () => {
    if (!photo) return Alert.alert('Add a photo first');
    if (!title.trim()) return Alert.alert('Give your pin a title');
 
    addPin({
      title: title.trim(),
      image: photo.uri,
      ratio: Math.min(Math.max(photo.height / photo.width, 0.6), 1.8), // keep shape reasonable
    });
 
    setPhoto(null);
    setTitle('');
    navigation.navigate('Home');
  };
 
  return (
    <ScrollView style={common.screen} contentContainerStyle={{ padding: 16, paddingTop: insets.top + 8 }}>
      <Text style={[common.title, { marginHorizontal: 0 }]}>New pin</Text>
 
      {/* PHOTO PREVIEW */}
      {photo ? (
        <Image source={{ uri: photo.uri }} style={styles.preview} />
      ) : (
        <View style={[styles.preview, styles.previewEmpty]}>
          <Text style={{ color: COLORS.mute }}>Choose a photo to pin</Text>
        </View>
      )}
 
      {/* GALLERY / CAMERA BUTTONS */}
      <View style={styles.row}>
        <TouchableOpacity testID="pick-gallery" style={common.buttonOutline} onPress={() => choosePhoto(false)}>
          <Ionicons name="images-outline" size={18} color={COLORS.ink} />
          <Text style={common.buttonOutlineText}>Gallery</Text>
        </TouchableOpacity>
        <TouchableOpacity testID="pick-camera" style={common.buttonOutline} onPress={() => choosePhoto(true)}>
          <Ionicons name="camera-outline" size={18} color={COLORS.ink} />
          <Text style={common.buttonOutlineText}>Camera</Text>
        </TouchableOpacity>
      </View>
 
      {/* TITLE + PUBLISH */}
      <TextInput
        testID="title-input"
        style={common.input}
        placeholder="Title"
        placeholderTextColor={COLORS.mute}
        value={title}
        onChangeText={setTitle}
      />
      <TouchableOpacity testID="save-pin" style={common.button} onPress={publish}>
        <Text style={common.buttonText}>Publish pin</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}
 
const styles = StyleSheet.create({
  preview: { width: '100%', height: 300, borderRadius: 20 },
  previewEmpty: {
    backgroundColor: COLORS.soft, alignItems: 'center', justifyContent: 'center',
    borderWidth: 1, borderStyle: 'dashed', borderColor: COLORS.line,
  },
  row: { flexDirection: 'row', gap: 10, marginVertical: 14 },
});